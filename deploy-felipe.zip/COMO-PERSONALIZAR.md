# Como personalizar o site

## 1. Dados do profissional
Edite apenas o arquivo: **assets/js/config.js**

Substitua os valores entre aspas com os dados reais:
- `whatsapp` — apenas números com DDD (ex: "11999999999")
- `instagram` — handle sem @ (ex: "felipemaiapsicopedagogo")
- `email`, `telefone`, `endereco`, `horario`, `formacao`
- `depoimentos` — substitua pelos depoimentos reais
- `faq` — edite perguntas e respostas

## 2. Fotos
Coloque os arquivos nas pastas:
- `assets/images/foto-hero.jpg` — foto principal (hero)
- `assets/images/foto-sobre.jpg` — foto da seção "Sobre"
- `assets/images/gallery/espaco-1.jpg` até `espaco-6.jpg` — galeria

## 3. Estrutura de arquivos
```
felipe-maia-site/
├── index.html                  ← página principal
├── assets/
│   ├── css/
│   │   └── style.css           ← todo o CSS
│   ├── js/
│   │   ├── config.js           ← ⭐ EDITE ESTE ARQUIVO
│   │   └── main.js             ← lógica do site
│   └── images/
│       ├── favicon.svg
│       ├── foto-hero.jpg       ← substitua
│       ├── foto-sobre.jpg      ← substitua
│       └── gallery/
│           ├── espaco-1.jpg    ← substitua
│           └── ...
```

## 4. Como abrir o site
Basta abrir o arquivo `index.html` no navegador.
Para hospedar, faça upload de toda a pasta para qualquer servidor ou use:
- Netlify Drop (netlify.com/drop)
- GitHub Pages
- Vercel
